<?php

// Start Session 

session_start();



$host="localhost";
$user="root";
$password="";
$database="food_order";

$conn= new mysqli($host,$user,$password,$database);


if($conn->connect_errno){
    echo "Connection failed";
}