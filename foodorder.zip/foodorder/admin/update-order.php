<?php
include("partials/menu.php");

?>


<?php


//  check Whether id is set or not

if (isset($_GET['id'])) {
     
    // Get The Order Details
    $id=$_GET['id'];

    // Get all Other Details Based On this Id
    // Sql Query to get Order Details
    $query="SELECT * FROM tbl_order WHERE id=$id";

    $res=$conn->query($query);

  

    // Count Rows

    $count= mysqli_num_rows($res);

   

    if ($count ==1) {
        
        // Detail Available
        $row=mysqli_fetch_assoc($res);
     
        $id=$row['id'];
        $food=$row['food'];
        $qty=$row['qty'];
        $total=$row['total'];
        $price=$row['price'];
        $status=$row['status'];
        $customer_name=$row['customer_name'];
        $customer_contact=$row['customer_contact'];
        $customer_email=$row['customer_email'];
        $customer_address=$row['customer_address'];



    }
    else {
        // Detail Not Available
        heade('location:manage-order.php');
    }
}
// else {
//     // Redirect to Manage Order Page
//     header("Location:manage-order.php");
// }




?>




<div class="container pt-5">
    <h1><b>UPDATE FOOD</b></h1>


    <form action="" method="POST"  class="mt-5">
      <table>
        <tr>
            <td>Food :</td>
            <td><b class="ms-5"><?php echo $food;  ?></b></td>
        </tr>

        <tr>
            <td>Price :</td>
            <td><b class="ms-5"><?php echo $price;  ?></b></td>
        </tr>
      </table>
  


  <div class="col mt-3 ms-1">
    <label for="">Qty :</label>
    <input type="number" class="ms-5" name="qty" value="<?php echo $qty?>" required>
  </div>

  <div class="col mt-3 ms-1">
    <label for="">Total :</label>
    <input type="number" class="ms-5" name="total" value="<?php echo $total?>" required>
  </div>

  <div class="col mt-3 ">
    <label for="">Status :</label>
    <select name="status" class="ms-5" >
        <option <?php if ($status=="Ordered") {echo "selected";}   ?> value="Ordered">Ordered</option>
        <option <?php if ($status=="On Delivery") {echo "selected";}   ?> value="On Delivery">On Delivery</option>
        <option <?php if ($status=="Delivered") {echo "selected";}   ?> value="Delivered">Delivered</option>
        <option <?php if ($status=="Cancelled") {echo "selected";}   ?> value="Cancelled">Cancelled</option>
    </select>
  </div>



  <div class="col mt-3 ">
    <label for="">Customer <br> Name :</label>
    <input type="text" class="ms-5" name="customer_name"  value="<?php echo $customer_name?>" required>
  </div>

  <div class="col mt-3">
    <label for="">Customer <br> Contact :</label>
    <input type="text" class="ms-5" name="customer_contact"  value="<?php echo $customer_contact?>" required>
  </div>

  <div class="col mt-3">
    <label for="">Customer <br> Email :</label>
    <input type="text" class="ms-5" name="customer_email"  value="<?php echo $customer_email?>" required>
  </div>

  
  <div class="col mt-3">
    <label for="">Customer <br> Address :</label>
    <input type="text" class="ms-5" name="customer_address"  value="<?php echo $customer_address?>" required>
  </div>

  <div class="col-md-4 mt-3 mb-5">
    <input type="submit" class="btn-warning btn" name="submit" value="Update Order" required>
  </div>
</form>

<?php
//  Check Whether the Button is Clicked Or not
if (isset($_POST['submit'])) {
    
    // Get The All Value From Form
    // $id=$_POST['id'];
    // $price=$_POST['price'];
    $qty=$_POST['qty'];

    $total= $price * $qty;

    $status=$_POST['status'];

    $customer_name=$_POST['customer_name'];
    $customer_contact=$_POST['customer_contact'];
    $customer_email=$_POST['customer_email'];
    $customer_address=$_POST['customer_address'];

    $q="UPDATE tbl_order SET 
    qty = $qty,
    total=$total,
    status = '$status',
    customer_name='$customer_name',
    customer_contact='$customer_contact',
    customer_email = '$customer_email',
    customer_address = '$customer_address'
    WHERE id = $id
    ";

    $res2=$conn->query($q);

    if($res2){
      
        header("Location:manage-order.php");
    }


}



?>

    </div>


<?php
include("partials/footer.php");

?>