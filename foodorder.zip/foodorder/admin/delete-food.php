<?php
require "../connection/config.php";

if (isset($_GET)) {
    $id=$_GET["id"];

    $query="DELETE FROM tbl_food WHERE id=$id";

    $res=$conn->query($query);

    if($res){
        header("Location:manage-food.php");
    }
}


?>