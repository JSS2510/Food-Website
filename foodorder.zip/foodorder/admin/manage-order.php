<?php
include("partials/menu.php");

?>

 <!-- Main Content Section Start  -->
 <div class="main-content">
    <div class="wrapper">
       <h1>Manage Order</h1>

       <!-- Button to Add Order -->

       <!-- <a href="#" class="btn-primary btn">Add Order</a> -->

       <table class="table table-success table-striped mt-4">
       <tr>
            <th>Sr.No</th>
            <th>Food</th>
            <th>Price</th>
            <th>Qty.</th>
            <th>Total</th>
            <th>Order Date</th>
            <th>Status</th>
            <th>Name</th>
            <th>Contact</th>
            <th>Email</th>
            <th>Address</th>
            <th>Action</th>
        </tr>

        <?php

$query="SELECT * FROM tbl_order ORDER BY id DESC";  //Display the latest Order First

$res=$conn->query($query);

$count=mysqli_num_rows($res);
// echo "$total";

$sn = 1; //Create a Serila Number And set its Value as 1



// $result=mysqli_fetch_assoc($res);

// echo"$result[name]";



if ($count > 0) {
    // echo "Table has Records";
    while ($row=mysqli_fetch_assoc($res)) {
        // Order Available
        $id=$row['id'];
        $food=$row['food'];
        $price=$row['price'];
        $qty=$row['qty'];
        $total=$row['total'];
        $order_date=$row['order_date'];
        $status=$row['status'];
        $customer_name=$row['customer_name'];
        $customer_contact=$row['customer_contact'];
        $customer_email=$row['customer_email'];
        $customer_address=$row['customer_address'];

        ?>

             <tr>
                <td><?php echo $sn++;  ?>. </td>
                <td><?php echo $food;  ?>. </td>
                <td><?php echo $price;  ?>. </td>
                <td><?php echo $qty;  ?>. </td>
                <td><?php echo $total;  ?>. </td>
                <td><?php echo $order_date;  ?>. </td>

                <td>
                    <?php
                     
                     if ($status=="Ordered") {
                        
                        echo "<label>$status</label";
                     }
                     elseif($status=="On Delivery"){
                         echo "<label style='color:orange'>$status</label>";
                     }
                     elseif($status=="Delivered"){
                        echo "<label style='color:green'>$status</label>";
                    }
                    elseif($status=="Cancelled"){
                        echo "<label style='color:red'>$status</label>";
                    }
                    ?>. 
                 </td>

                <td><?php echo $customer_name;  ?>. </td>
                <td><?php echo $customer_contact;  ?>. </td>
                <td><?php echo $customer_email;  ?>. </td>
                <td><?php echo $customer_contact;  ?>. </td>

                <td>
                    <a href="update-order.php?id=<?php echo $id;?>" class="btn-secondary btn">Update Order</a>
                </td>
             </tr>


        <?php
        
    }
}else{
    echo "No Records Form";
}

 ?>


       
</table>

     </div>
    </div>
    
    <!-- Main Content Section End  -->



<?php
include("partials/footer.php");

?>