<?php
require "../connection/config.php";

if (isset($_GET)) {
    $id=$_GET["id"];

    $query="DELETE FROM tbl_category WHERE id=$id";

    $res=$conn->query($query);

    if($res){
        header("Location:manage-category.php");
    }
}


?>