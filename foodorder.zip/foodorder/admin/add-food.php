<?php
include ("partials/menu.php");
?>


<div class="main-content">
    <div class="wrapper">
       <h1 class="mb-4">Add Food</h1>

         <!-- Checking Wheather the session is set or not -->
         <?php 
       
       if (isset($_SESSION['upload'])) 
       {
        echo $_SESSION['upload'];  //Displaying the Session Message
        unset($_SESSION['upload']);  //Removing Session Message  
       }

        ?>

       <form action="" method="POST" enctype="multipart/form-data">
<div class="col">
    <label for="">Title :</label>
    <input type="text" class="ms-5" name="title" placeholder="Food title" required>
  </div>

  <div class="col-6 mt-3">
    <label for="" >Description :</label>
    <textarea name="description" id="" cols="25" rows="3" placeholder="Food Description" class="p-2"></textarea>
  </div>

  <div class="col-md-4 mt-3">
    <label for="">Price :</label>
    <input type="number" class="ms-5" name="price"  required>
  </div>

  <div class="col mt-3">
    <label for="">Select <br> Image :</label>
    <input type="file" class="ms-5 " name="image" >
  </div>

  <div class="col-md-4  mt-3">
  <label for="category">Category :</label>
    <select name="category" id="category" class="ms-3">

    <?php
    $query="SELECT * FROM tbl_category";

    $res=$conn->query($query);
    
    while ($data1=$res->fetch_object()){
     
   
echo '<option value="'.$data1->id.'">'.$data1->title.'</option>';

    }


?>

    </select>
</div>

  <div class="col-md-4 mt-3">
  <label for="">Featured :</label>
    <input type="radio" class="ms-3" name="featured" value="Yes"  required>Yes
    <input type="radio" class="ms-3" name="featured" value="No"  required>No
  </div>

  <div class="col-md-4 mt-3">
  <label for="">Active :</label>
    <input type="radio" class="ms-4" name="active" value="Yes" required>Yes
    <input type="radio" class="ms-3" name="active" value="No" required>No
  </div>

  <div class="col-md-4 mt-3">
    <input type="submit" class="btn-warning btn" name="submit" value="Add Food" required>
  </div>
</form>

<?php

// Check Wheather the button is click or not

if (isset($_POST['submit'])) {
    // echo"<pre>";
    // print_r($_POST);
    // Add the food in Database
    $title=$_POST['title'];
    $description=$_POST['description'];
    $price=$_POST['price'];
    $category=$_POST['category'];

    // Check Wheather radio button for featured and active are checked or not

    if (isset($_POST['featured'])) {
        $featured = $_POST['featured'];
    }
    else {
        $featured= "No"; //Setting the default value
    }

    if (isset($_POST['active'])) {
        $active = $_POST['active'];
    }
    else {
        $active = "No"; //Setting the default value
    }

    // Check Weather the select image is clicked or not
    if (isset($_FILES['image']['name'])) {
        
        $image_name=$_FILES['image']['name'];

        // Check Whether the image is slected  or not and upload images 

        if ($image_name!="") {
            // Image is selected

            // Get the extension of selected  image (jpg. jpeg .png) 

            $ext= end(explode('.', $image_name));

        //    Create a New Name For Image

            $image_name = "Food-Name-".rand(000,999).".".$ext;  // New Image Name 

            $type=$_FILES["image"]["type"];

            $tmp_name=$_FILES["image"]["tmp_name"];
    
            $dst="../images/food/".$image_name;
           
            // Finally Upload Food Image
            $upload = move_uploaded_file($tmp_name,$dst);

             // If the image is not uploaded then we will stop the process and redirect with error message

        if ($upload==false) {
            
            // Set Message

            $_SESSION['upload'] = "<div class='error'>Failed to Upload Image</div>";

            // Redirect to Add Category Page
            header("Location:add-food.php");

            // Stop the Process
            die();
        }
    

    }
 
}
    else {
        $image_name= ""; //Setting Default value is Blank
    }

    // For numerical value we do naot need to pas the value inside single '' but for string value it is compulsary 

// $query="INSERT INTO `tbl_food` VALUES(title = '$title',description='$description',price=$price, image_name='$image_name', category_id='$category', featured='$featured', active='$active')";


$query="INSERT INTO `tbl_food` VALUES(Null,'$title','$description','$price','$image_name','$category', '$featured', '$active')";

$res= $conn->query($query) or die($conn->error);


// Check Wheather the query executed or not and data added or not

if ($res==TRUE) {

    // echo "data inserted";
    // Create a session variable

    $_SESSION['add'] ="Food Added Successfully";

    // Redirect Page manage Admin page

    header("Location: manage-food.php");

}
else {

    // echo "data Failed";

    $_SESSION['add'] ="Failed to add Food";

    // Redirect Page Add Admin page

    header("Location: add-food.php");

}

}


?>


</div>
</div>


    

<?php
include("partials/footer.php");
?>
