<?php
include ("partials/menu.php");
?>

<?php

    $id=$_GET["id"];

    $query="SELECT * FROM tbl_admin WHERE id=$id";

    $res=$conn->query($query);


    $data=$res->fetch_object();

    // echo "<pre>";
    // print_r($conn);
    // echo "</pre>";






?>



<div class="container">
    <h1><b>UPDATE ADMIN DATA</b></h1>
  
    <form action= "edit-admin.php" method="POST" enctype="multipart/form-data" class="mt-5">
    <div class="col-md-4">
    <input type="text" name="id" id="name" class="input" value="<?php echo $data->id?>" hidden>
    </div>
  
    <div class="col-md-4">
    <label for="">Full Name</label>
    <input type="text" class="ms-5" name="full_name" placeholder="Enter Your Name" value="<?php echo $data->full_name?>" required>
  </div>
  <div class="col-md-4 mt-3">
  <label for="">Username</label>
    <input type="text" class="ms-5" name="username" placeholder="Your Username" value="<?php echo $data->user_name?>" required>
  </div>
 
  
  <div class="col-12 mt-4 col1 mb-5">
      <input class="btn btn-warning  rounded-pill btn" type="submit" name="submit" value="Update Data">     
</div>

    </form>
  </div>
















<?php
include("partials/footer.php");
?>