<?php

include ("partials/menu.php");


if(isset($_POST["submit"])){
   
    $id=$_POST['id'];
    $full_name=$_POST['full_name'];
    $username=$_POST['username'];
    
   
    $query="UPDATE tbl_admin SET 
    full_name = '$full_name',
    user_name ='$username'
    WHERE id = '$id'
    ";

    $res=$conn->query($query);
 

    if($res){
      
        header("Location:manage-admin.php");
    }
    
}

?>