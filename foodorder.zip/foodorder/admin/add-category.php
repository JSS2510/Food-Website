<?php
include("partials/menu.php");

?>

<div class="main-content">
    <div class="wrapper">
       <h1 class="mb-4">Add Category</h1>

       <!-- Checking Wheather the session is set or not -->
       <?php 
        if (isset($_SESSION['add'])) {
           echo $_SESSION['add'];  //Displaying the Session Message
           unset($_SESSION['add']);  //Removing Session Message  
       }  
       
       if (isset($_SESSION['upload'])) {
        echo $_SESSION['upload'];  //Displaying the Session Message
        unset($_SESSION['upload']);  //Removing Session Message  
    } 




       ?>


<!-- Add Category Form Starts -->
<div class="container">
       <form action="" method="POST" enctype="multipart/form-data">
  <div class="col">
    <label for="">Title :</label>
    <input type="text" class="ms-5" name="title" placeholder="Category title" required>
  </div>

  <div class="col mt-2">
    <label for="">Select Image :</label>
    <input type="file" class="ms-5 " name="image" >
  </div>

  <div class="col-md-4 mt-3">
  <label for="">Featured :</label>
    <input type="radio" class="ms-3" name="featured" value="Yes"  required>Yes
    <input type="radio" class="ms-3" name="featured" value="No"  required>No
  </div>
  <div class="col-md-4 mt-3">
  <label for="">Active :</label>
    <input type="radio" class="ms-4" name="active" value="Yes" required>Yes
    <input type="radio" class="ms-3" name="active" value="No" required>No
  </div>
  <div class="col-md-4 mt-3">
    <input type="submit" class="btn-warning btn" name="submit" value="Add Category" required>
  </div>
</form>
</div>
</div>
</div>

<!-- Add Category Form End -->

<?php

// Check Wheather the submit button is click or not

if (isset($_POST['submit'])) {

    // echo "Clicked";

    // Get the Value From Category Form

    $title = $_POST['title'];

    // for Radio input, we need to check wheather the button is clicked or not

    if (isset($_POST['featured'])) {

        // Get the value from Form

        $featured=$_POST['featured'];

    }
    else{

        // Set the default value

        $featured="No";
    }

    if (isset($_POST['active'])) {

        // Get the value from Form

        $active=$_POST['active'];

    }
    else{

        // Set the default value

        $active="No";
    }

    // Check wheather the image is slected or not and the set the value for image name accoridingly

    // print_r($_FILES['image']);

    // die(); //Break code here

    if (isset($_FILES['image']['name'])) {

        // Upload the image
        // To upload the image we need image name and source path and destination path

        $image_name=$_FILES['image']['name'];

        // Auto Rename the image
        // Get the Ectension of or image jpg png jpeg  
        $ext= end(explode('.', $image_name));

        // Rename the image

        $image_name = "Food_Category_".rand(000, 999).'.'.$ext;  // NEw Image Name is Food_Cate_

        $type=$_FILES["image"]["type"];

        $tmp_name=$_FILES["image"]["tmp_name"];

        $upload="../images/category/".$image_name;
       
        // Finally Upload Image
        $upload = move_uploaded_file($tmp_name,$upload);


        // Check Wheather the Image is uploaded or not 
        // If the image is not uploaded then we will stop the process and redirecr with error message

        if ($upload==false) {
            
            // Set Message

            $_SESSION['upload'] = "<div class='error'>Failed to Upload Image</div>";

            // Redirect to Add Category Page
            header("Location:add-category.php");

            // Stop the Process
            die();
        }
        

    }
    else {

        // Don't Upload The Image and set the image value as blank

        $image_name="";

    }

// Create SQL Query to Insert Category into Database

$query="INSERT INTO `tbl_category` SET
title = '$title',
image_name='$image_name',
featured ='$featured',
active ='$active'
";

$res= $conn->query($query) or die($conn->error);


// Check Wheather the query executed or not and data added or not

if ($res==TRUE) {

    // echo "data inserted";
    // Create a session variable

    $_SESSION['add'] ="Category Added Successfully";

    // Redirect Page manage Admin page

    header("Location:manage-category.php");

}
else {

    // echo "data Failed";

    $_SESSION['add'] ="Failed to add Category";

    // Redirect Page Add Admin page

    header("Location: add-category.php");

}

}





?>










<?php
include("partials/footer.php");

?>