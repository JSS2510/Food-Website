<?php
include ("../connection/config.php");

// Destroy the session 

session_destroy();   

// Redirect to Login page

header("Location:login.php");









?>