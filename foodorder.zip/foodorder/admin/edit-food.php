<?php

include ("partials/menu.php");


if(isset($_POST["submit"])){
   
    $id=$_POST['id'];
    $title=$_POST['title'];
    $price=$_POST['price'];
    $image_name=$_FILES["image"]["name"];
    $category_id=$_POST["category_id"];
    $featured=$_POST['featured'];
    $active=$_POST['active'];
    
   
    $query="UPDATE tbl_food SET 
    title = '$title',
    price = '$price',
    image_name='$image_name',
    category_id='$category_id',
    featured = '$featured',
    active = '$active'
    WHERE id = '$id'
    ";

    $res=$conn->query($query);
 

    if($res){
      
        header("Location:manage-food.php");
    }
    
}

?>