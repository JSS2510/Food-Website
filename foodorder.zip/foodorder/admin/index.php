<?php
include ("partials/menu.php");
?>



    <!-- Main Content Section Start  -->
    <div class="main-content">
    <div class="wrapper">
       <h1>Dashboard</h1>
<div class="row">
       <div class="col-3 col">

       <?php
         
         $query="SELECT * FROM tbl_category";

        // Execute Query
        $res=$conn->query($query);

         // Count Rows
         $count= mysqli_num_rows($res);



       ?>
           <h1><?php echo $count;   ?></h1> <br>
           Categories
       </div>

       <div class="col-3 col">

       <?php
         
         $query2="SELECT * FROM tbl_food";

        // Execute Query
        $res2=$conn->query($query2);

         // Count Rows
         $count2= mysqli_num_rows($res2);



       ?>
           <h1><?php  echo $count2   ?></h1> <br>
           Foods
       </div>

       <div class="col-3 col">

       <?php
         
         $query3="SELECT * FROM tbl_order";

        // Execute Query
        $res3=$conn->query($query3);

         // Count Rows
         $count3= mysqli_num_rows($res3);



       ?>
           <h1><?php  echo $count3   ?></h1> <br>
           Foods
       </div>

       <div class="col-3 col">

       <?php
        
        // Create Sql Query to Get Total Revenue
        // USe Aggregate Function in Sql

        $query4="SELECT SUM(total) AS Total FROM tbl_order WHERE status='Delivered'";

        // Execute Query
        $res4=$conn->query($query4);

        // Get The Value

        $row4=mysqli_fetch_assoc($res4);

        // Get the Total Revenue 
        $total_revenue=$row4['Total'];

        ?>
           <h1>₹<?php  echo $total_revenue    ?></h1> <br>
           Revenue Generated
       </div>

       </div>
     </div>
    </div>
    <!-- Main Content Section End  -->

<?php

include("partials/footer.php")


?>