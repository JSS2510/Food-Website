<?php
include ("partials/menu.php");
?>

<div class="main-content">
    <div class="wrapper">
       <h1 class="mb-4">Add Admin</h1>

       <!-- Checking Wheather the session is set or not -->
       <?php  if (isset($_SESSION['add'])) {
           echo $_SESSION['add'];  //Displaying the Session Message
           unset($_SESSION['add']);  //Removing Session Message  
       }  
       ?>

       <form action="" method="POST">
  <div class="col-md-4">
    <label for="">Full Name</label>
    <input type="text" class="ms-5" name="full_name" placeholder="Enter Your Name" required>
  </div>
  <div class="col-md-4 mt-3">
  <label for="">Username</label>
    <input type="text" class="ms-5" name="username" placeholder="Your Username" required>
  </div>
  <div class="col-md-4 mt-3">
  <label for="">Password</label>
    <input type="password" class="ms-5" name="password" placeholder="Enter Your Password" required>
  </div>
  <div class="col-md-4 mt-3">
    <input type="submit" class="btn-warning btn" name="submit" value="Add Admin" required>
  </div>
</form>
</div>
</div>







<?php
include("partials/footer.php");
?>


<?php
// Process The Value from Form and Save it to The DataBase
//Check Wheather the Submit Button is Click or Not



if (isset($_POST['submit'])) {
    // Button Clicked
    // echo"button Clicked";

    $full_name=$_POST['full_name'];
    $username=$_POST['username'];
    $password=$_POST['password'];     //Password Encryption with MD5

    $query="INSERT INTO `tbl_admin` SET
    full_name = '$full_name',
    user_name ='$username',
    password ='$password'
    ";

    // Execute the query and save data in database

    $res= $conn->query($query) or die($conn->error);

    // Check Wheather the (Query is Executed) data is inserted or not and display appropriate message

    if ($res==TRUE) {
        // echo "data inserted";
        // Create a session variable
        $_SESSION['add'] ="Admin Added Successfully";
        // Redirect Page manage Admin page
        header("Location: manage-admin.php");
    }
    else {
        // echo "data Failed";
        $_SESSION['add'] ="Failed to add Admin";
        // Redirect Page Add Admin page
        header("Location: add-admin.php");
    }

    


}






?>