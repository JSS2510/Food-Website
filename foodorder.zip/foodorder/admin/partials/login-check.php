<?php

// Authorization - Access Control

// Check Weather the user login or not
// session_start();
// session_destroy();

if(isset($_SESSION['login'])){
    //  User is Not Login
    // Redirect To Login Pahe with Message
    
}
else{
    header("Location:login.php");
}



?>  