<?php
include("partials/menu.php");

?>

 <!-- Main Content Section Start  -->
 <div class="main-content">
    <div class="wrapper">
       <h1>Manage Category</h1>
       <?php  if (isset($_SESSION['add'])) {
           echo $_SESSION['add'];  //Displaying the Session Message
           unset($_SESSION['add']);  //Removing Session Message  
       }  
       ?>

<!-- Button to Add Category -->

<a href="add-category.php" class="btn-primary btn">Add Category</a>

<table class="table table-success table-striped mt-4">
<tr>
     <th>Sr.No</th>
     <th>Title</th>
     <th>Image</th>
     <th>Active</th>
     <th>Featured</th>
     <th>Action</th>
 </tr>


 <?php

$query="SELECT * FROM tbl_category";

$res=$conn->query($query);

$total=mysqli_num_rows($res);
// echo "$total";



$result=mysqli_fetch_assoc($res);

// echo"$result[name]";



if ($total != 0) {
    // echo "Table has Records";
}else{
    echo "No Records Form";
}

while ($data=$res->fetch_object()) {
     echo "<tr>";
     echo '<td>' .$data->id. '</td>';
     echo '<td>' .$data->title. '</td>';
     echo '<td><img src="../images/category/'.$data->image_name.'" height="100px" width="100px"</td>';
     echo '<td>' .$data->featured. '</td>';
     echo '<td>' .$data->active. '</td>';
     echo '<td> <a href=update-category.php?id='.$data->id.'><input type="submit" value="Update" class="update btn btn-success"></a>

       <a href=delete-category.php?id='.$data->id.'><input type="submit" value="Delete" class="delete btn btn-danger" onclick = "return checkdelete()"></a></td>';
     echo "</tr>";
}

?>













</table>

     </div>
    </div>
    
    <!-- Main Content Section End  -->



<?php
include("partials/footer.php");

?>