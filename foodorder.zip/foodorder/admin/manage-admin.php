<?php
include ("partials/menu.php");
?>

    <!-- Main Content Section Start  -->
    <div class="main-content">
    <div class="wrapper">
       <h1 class="mb-4">Manage Admin</h1>

       <?php  if (isset($_SESSION['add'])) {
           echo $_SESSION['add'];  //Displaying the Session Message
           unset($_SESSION['add']);  //Removing Session Message  
       }  

       if (isset($_SESSION['pass-not-found'])) {
        echo $_SESSION['pass-not-found'];  //Displaying the Session Message
        unset($_SESSION['pass-not-found']);  //Removing Session Message  
    } 

    if (isset($_SESSION['user-not-found'])) {
        echo $_SESSION['user-not-found'];  //Displaying the Session Message
        unset($_SESSION['user-not-found']);  //Removing Session Message  
    } 

    // if (isset($_SESSION['change-pass'])) {
    //     echo $_SESSION['change-pass'];  //Displaying the Session Message
    //     unset($_SESSION['change-pass']);  //Removing Session Message  
    // } 



       ?>
       <!-- Button to Add Admin -->

       <a href="add-admin.php" class="btn-primary btn">Add Admin</a>

       <table class="table table-success table-striped mt-4">
       <tr>
            <th>Sr.No</th>
            <th>Full Name</th>
            <th>User Name</th>
            <th>Action</th>
        </tr>

        <?php

$query="SELECT * FROM tbl_admin";

$res=$conn->query($query);

$total=mysqli_num_rows($res);
// echo "$total";



$result=mysqli_fetch_assoc($res);

// echo"$result[name]";



if ($total != 0) {
    // echo "Table has Records";
}else{
    echo "No Records Form";
}

while ($data=$res->fetch_object()) {
     echo "<tr>";
     echo '<td>' .$data->id. '</td>';
     echo '<td>' .$data->full_name. '</td>';
     echo '<td>' .$data->user_name. '</td>';
     echo '<td> <a href=change-admin-pass.php?id='.$data->id.'><input type="submit" value="Change Password" class="update btn btn-info text-light"></a>

      <a href=update-admin.php?id='.$data->id.'><input type="submit" value="Update" class="update btn btn-success"></a>

       <a href=delete-admin.php?id='.$data->id.'><input type="submit" value="Delete" class="delete btn btn-danger" onclick = "return checkdelete()"></a></td>';
     echo "</tr>";
}

?>
</table>

     </div>
    </div>

    <!-- Main Content Section End  -->

    <script>
 function checkdelete()
 {
  return confirm('Are You Sure You Want to Delete This Record?');
 }

</script>





<?php
include("partials/footer.php");
?>