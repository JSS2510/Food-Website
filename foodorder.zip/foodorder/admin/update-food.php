<?php
include ("partials/menu.php");
?>

<?php


    $id=$_GET["id"];

    $query="SELECT * FROM tbl_food WHERE id=$id";

    $res=$conn->query($query);


    $data=$res->fetch_object();

    // echo "<pre>";
    // print_r($data);
    // echo "</pre>";

    $featured=$data->featured;

    $active=$data->active;




?>


<div class="container pt-5">
<h1><b>UPDATE FOOD</b></h1>

       <form action="edit-food.php" method="POST" enctype="multipart/form-data">
       <div class="col-md-4 mt-5" >
    <input type="text" name="id" id="name" class="input" value="<?php echo $data->id?>" hidden>
    </div>

  <div class="col">
    <label for="">Title :</label>
    <input type="text" class="ms-5" name="title" placeholder="Category title" value="<?php echo $data->title?>" required>
  </div>

  
  <div class="col mt-3">
    <label for="">Price :</label>
    <input type="number" class="ms-5" name="price" placeholder="Food Price" value="<?php echo $data->price?>" required>
  </div>
  

  <div class="col mt-3">
    <label for="">Current Image :</label>
    <input type="file" class="ms-5 " name="image" value="<?php echo $data->image_name?>">
  </div>

  
  <div class="col mt-3">
    <label for="">Category Id :</label>
    <input type="text" class="ms-5" name="category_id" placeholder="Food Category Id" value="<?php echo $data->category_id?>" required>
  </div>

  <div class="col-md-4 mt-3">
  <label for="">Featured :</label>
    <input <?php if($featured =="Yes"){echo "checked";}   ?> type="radio" class="ms-3" name="featured" value="Yes"  required>Yes
    <input <?php if($featured =="No"){echo "checked";}   ?> type="radio" class="ms-3" name="featured" value="No"  required>No
  </div>
  <div class="col-md-4 mt-3">
  <label for="">Active :</label>
    <input <?php if($active =="Yes"){echo "checked";}   ?> type="radio" class="ms-4" name="active" value="Yes" required>Yes
    <input <?php if($active =="No"){echo "checked";}   ?> type="radio" class="ms-3" name="active" value="No" required>No
  </div>
  <div class="col-md-4 mt-3 mb-5">
    <input type="submit" class="btn-warning btn" name="submit" value="Update Food" required>
  </div>
</form>
</div>





<?php
include("partials/footer.php");
?>