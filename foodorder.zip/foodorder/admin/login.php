<?php

require "../connection/config.php";

if (isset($_POST['submit'])) {
    $username=mysqli_real_escape_string($conn,$_POST['username']);
    $password=mysqli_real_escape_string($conn,$_POST['password']);

    $q="SELECT * FROM tbl_admin WHERE user_name = '$username' AND password = '$password'";

    $res=$conn->query($q);


    if ($res->num_rows==1) {
        session_start();
        $_SESSION["login"] = True;
        $_SESSION["user_name"] = $username; //To check weather the user is login or not 
        $_SESSION["password"] = $password;
        
        header("Location:index.php");
    }
    else {
        echo "login failed incorrect username or password <br>";
        echo '<a href="login.php">Back To Login</a>';
    }
}


?>



<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login - Food Order System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/admin.css">
    <style>
      body{
        background-color: #063970;
      }
    </style>
  </head>
  <body>
    <div class="container ">
     <div class="login text-center bg-info">
        <h1><b>Login</b></h1>

        <!-- Login Form Start Here -->

         
       <form action="" method="POST">
  
  <div class="col-md-12 mt-3">
  <label for="">Username :</label>
    <input type="text" class="py-1" name="username" placeholder="Your Username" required>
  </div>
  <div class="col-md-12 mt-3">
  <label for="">Password :</label>
    <input type="password" class="py-1" name="password" placeholder="Enter Your Password" required>
  </div>
  <div class="col-md-12 mt-3 mb-4">
    <input type="submit" class="btn-primary btn px-5" name="submit" value="Login " required>
    <div class="signup mt-3">New Member ? <a href="add-admin.php" class="link">Sign Up Here</a></div>
</div>
</form>
   



        <!-- Login Form End Here -->


        <p>Created By - <a href="#">Jayesh Sharma</a></p>
     </div>
     </div>








    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  </body>
</html>