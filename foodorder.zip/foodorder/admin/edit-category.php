<?php

include ("partials/menu.php");


if(isset($_POST["submit"])){
   
    $id=$_POST['id'];
    $title=$_POST['title'];
    $image_name=$_FILES["image"]["name"];
    $featured=$_POST['featured'];
    $active=$_POST['active'];
    
   
    $query="UPDATE tbl_category SET 
    title = '$title',
    image_name='$image_name',
    featured = '$featured',
    active = '$active'
    WHERE id = '$id'
    ";

    $res=$conn->query($query);
 

    if($res){
      
        header("Location:manage-category.php");
    }
    
}

?>