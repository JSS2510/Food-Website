<?php
include ("partials/menu.php");
?>

<?php


    $id=$_GET["id"];

    $query="SELECT * FROM tbl_category WHERE id=$id";

    $res=$conn->query($query);


    $data=$res->fetch_object();

    // echo "<pre>";
    // print_r($data);
    // echo "</pre>";

    $featured=$data->featured;

    $active=$data->active;




?>


<div class="container pt-5">
<h1><b>UPDATE CATEGORY</b></h1>

       <form action="edit-category.php" method="POST" enctype="multipart/form-data">
       <div class="col-md-4 mt-5" >
    <input type="text" name="id" id="name" class="input" value="<?php echo $data->id?>" hidden>
    </div>

  <div class="col">
    <label for="">Title :</label>
    <input type="text" class="ms-5" name="title" placeholder="Category title" value="<?php echo $data->title?>" required>
  </div>

  <div class="col mt-2">
    <label for="">Current Image :</label>
    <input type="file" class="ms-5 " name="image" value="<?php echo $data->image?>">

  </div>

  <div class="col-md-4 mt-3">
  <label for="">Featured :</label>
    <input <?php if($featured =="Yes"){echo "checked";}   ?> type="radio" class="ms-3" name="featured" value="Yes"  required>Yes
    <input <?php if($featured =="No"){echo "checked";}   ?> type="radio" class="ms-3" name="featured" value="No"  required>No
  </div>
  <div class="col-md-4 mt-3">
  <label for="">Active :</label>
    <input <?php if($active =="Yes"){echo "checked";}   ?> type="radio" class="ms-4" name="active" value="Yes" required>Yes
    <input <?php if($active =="No"){echo "checked";}   ?> type="radio" class="ms-3" name="active" value="No" required>No
  </div>
  <div class="col-md-4 mt-3 mb-5">
    <input type="submit" class="btn-warning btn" name="submit" value="Update Category" required>
  </div>
</form>
</div>
















<?php
include("partials/footer.php");
?>