<?php
include ("partials/menu.php");
?>

<?php

    $id=$_GET["id"];

    $query="SELECT * FROM tbl_admin WHERE id=$id";

    $res=$conn->query($query);


    $data=$res->fetch_object();

    // echo "<pre>";
    // print_r($conn);
    // echo "</pre>";






?>



<div class="container mt-3">
<h1><b>CHANGE ADMIN PASSWORD</b></h1>

<form action= "" method="POST" enctype="multipart/form-data" class="mt-5">
<div class="col-md-6">
    <input type="text" name="id" id="name" class="input" value="<?php echo $data->id?>" hidden>
    </div>
  
<div class="col-md-6 mt-3">
  <label for="">Current Password</label>
    <input type="password" class="ms-4" name="current_password" placeholder="Current Password"  required>
  </div>

  <div class="col-md-6 mt-3">
  <label for="">New Password</label>
    <input type="password" class="ms-5" name="new_password" placeholder="New Password" required>
  </div>
  <div class="col-md-6 mt-3">
  <label for="">Confirm Password</label>
    <input type="password" class="ms-4" name="confirm_password" placeholder="New Password" required>
  </div>

  <div class="col-12 mt-4 col1 mb-5">
      <input class="btn btn-warning  rounded-pill btn" type="submit" name="submit" value="Change Password">     
</div>

</form>
</div>



<?php

// Check the wheather the submit button is click or not

if (isset($_POST['submit'])) {
    
    // Get the Data from Form
    $id=$_POST['id'];
    $current_password =$_POST['current_password'];
    $new_password =$_POST['new_password'];
    $confirm_password =$_POST['confirm_password'];

    // Check Wheather the user with current id and current password Exist oe not

    $query= "SELECT * FROM tbl_admin WHERE id = $id AND password ='$current_password'";

    // Execute the Query
     
    $res= $conn->query($query) or die($conn->error);

    if ($res==TRUE) {
        // Check Weather the data is Available or not

        $count=mysqli_num_rows($res);

        if ($count==1) {
        //   Users Exists and password can be changed
     
        //  echo "user Found";
        // Check Weather the new password and confirm password match or not

        if($new_password==$confirm_password){
            // Update the Password 
            $query2= "UPDATE tbl_admin SET
            password='$new_password'
            WHERE id=$id
            ";
             $res=$conn->query($query2);
 

             if($res){
                $_SESSION['change-pass'] = "<div class='sucess'>Password Change Successfully</div>";
                 header("Location:manage-admin.php");
             }
             else {
                $_SESSION['change-pass'] = "<div class='error'>Failed To Change Password</div>";
                header("Location:manage-admin.php");
             }
             


        }else {
            // redirect to manage admin page with error message
            $_SESSION['pass-not-found'] = "<div class='error'>Password Did Not Match</div>";
            header("location:manage-admin.php");
        }


        }
        else {
            // User Does not Exist 
            $_SESSION['user-not-found'] = "<div class='error'>User Not Found</div>";
            header("location:manage-admin.php");
        }
    }

    

    // Change Password if all above is true
}


?>















<?php
include("partials/footer.php");
?>